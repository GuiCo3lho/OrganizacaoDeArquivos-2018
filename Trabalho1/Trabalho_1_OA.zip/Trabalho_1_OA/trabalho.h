void criarindicep(FILE*,char*);
int countregisters(FILE*);
void criarinds(void);
